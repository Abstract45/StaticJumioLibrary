//
//  NVScanController.h
//
//  Copyright © 2021 Jumio Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

#ifndef NV_SCAN_CONTROLLER_H
#define NV_SCAN_CONTROLLER_H

__attribute__((visibility("default"))) @interface NVScanController : NSObject

@end

#endif

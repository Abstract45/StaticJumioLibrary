//
//  NetverifyBarcode.h
//
//  Copyright © 2021 Jumio Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NetverifyBarcode.
FOUNDATION_EXPORT double NetverifyBarcodeVersionNumber;

//! Project version string for NetverifyBarcode.
FOUNDATION_EXPORT const unsigned char NetverifyBarcodeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NetverifyBarcode/PublicHeader.h>

#import <NetverifyBarcode/NVBarCodeScanViewController.h>

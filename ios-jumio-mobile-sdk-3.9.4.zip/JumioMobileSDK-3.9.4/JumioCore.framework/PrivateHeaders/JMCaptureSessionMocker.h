//
//  JMCaptureSessionMocker.h
//
//  Copyright © 2021 Jumio Corporation. All rights reserved.
//

#import <JumioCore/JumioCore.h>

__attribute__((visibility("default"))) @interface JMCaptureSessionMocker : NSObject


@end

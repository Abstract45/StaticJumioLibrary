//
//  JMCircularLoadingView.h
//
//  Copyright © 2021 Jumio Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

__attribute__((visibility("default"))) @interface JMCircularLoadingView : UIView

- (void)startAnimation;

@end

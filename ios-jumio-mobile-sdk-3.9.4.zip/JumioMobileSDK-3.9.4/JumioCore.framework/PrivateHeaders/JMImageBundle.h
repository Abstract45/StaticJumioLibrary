//
//  JMImageBundle.h
//
//  Copyright © 2021 Jumio Corporation. All rights reserved.
//
//  Class to prevent that merchants can exchange the "powerdByJumio"-Images
//

#import <Foundation/Foundation.h>

__attribute__((visibility("default"))) @interface JMImageBundle : NSObject

@end

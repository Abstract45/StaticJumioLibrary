//
//  JMNegativeButton.h
//
//  Copyright © 2021 Jumio Corporation. All rights reserved.
//

#import <JumioCore/JMSubmitButton.h>

__attribute__((visibility("default"))) @interface JMNegativeButton : JMSubmitButton

@end

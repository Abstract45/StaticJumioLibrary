//
//  JMCryptoPPZipUtilities.h
//
//  Copyright © 2021 Jumio Corporation. All rights reserved.
//

__attribute__((visibility("default"))) @interface JMCryptoPPZipUtilities : NSObject

+(NSData*) unzipData:(NSData*)zipData;

@end
